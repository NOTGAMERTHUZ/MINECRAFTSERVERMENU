rootProject.name = "ThuzMenu"
